using BookCatalog.Controllers;
using BookCatalog.Dtos;
using BookCatalog.Models;
using BookCatalog.Repo;
//using BookCatalog_UnitTest.MockData;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookCatalog_UnitTest
{
    public class BooksController_Test
    {
        [SetUp]
        public void Setup()
        {
        }

        //[Test]
        //public void GetBook_WithUnExistaningData_1()
        //{
        //    //Arrange
        //    InMemoBookRepo bookRepo = new InMemoBookRepo();
        //    string val = Guid.NewGuid().ToString();

        //    //Act
        //    var book = bookRepo.GetBook(val);

        //    //Assert
        //    if (book == null)
        //        Assert.Pass();

        //    Assert.Fail();
        //}

        //[Test]
        //public void GetBook_WithNoData()
        //{
        //    //Arrange
        //    InMemoBookRepo bookRepo = new InMemoBookRepo();

        //    //Act
        //    var book = bookRepo.GetBook(string.Empty);

        //    //Assert
        //    if (book == null)
        //        Assert.Pass();

        //    Assert.Fail();
        //}

        //[Test]
        //public void GetBook_WithExistaningData()
        //{
        //    //Arrange
        //    InMemoBookRepo bookRepo = new InMemoBookRepo();
        //    bookRepo.CreateBook(new CreateOrUpdateBookDto { Title = "A Book", Author = "Avinaba Srimany", Price = 1 });
        //    BookDto _book = bookRepo.GetBook("A Book");

        //    //Act
        //    var book = bookRepo.GetBook(_book.ISBN);

        //    //Assert
        //    if (book.ISBN == _book.ISBN)
        //        Assert.Pass();

        //    Assert.Fail();
        //}

        //[Test]
        //public void GetBooks_WithExistaningData()
        //{
        //    //Arrange
        //    InMemoBookRepo bookRepo = new InMemoBookRepo();
        //    bookRepo.CreateBook(new CreateOrUpdateBookDto { Title = "A Book", Author = "Avinaba Srimany", Price = 1 });
        //    BookDto _book = bookRepo.GetBook("A Book");

        //    //Act
        //    var book = bookRepo.GetBooks().ToList();

        //    //Assert
        //    if (book[0] == _book && book.Count == 1)
        //        Assert.Pass();

        //    Assert.Fail();
        //}

        //[Test]
        //public void GetBooks_WithNoData()
        //{
        //    //Arrange
        //    InMemoBookRepo bookRepo = new InMemoBookRepo();

        //    //Act
        //    var book = bookRepo.GetBooks().ToList();

        //    //Assert
        //    if (book.Count == 0)
        //        Assert.Pass();

        //    Assert.Fail();
        //}

        //[Test]
        //public void DeleteBook_WithExistaningData()
        //{
        //    //Arrange
        //    InMemoBookRepo bookRepo = new InMemoBookRepo();
        //    bookRepo.CreateBook(new CreateOrUpdateBookDto { Title = "A Book", Author = "Avinaba Srimany", Price = 1 });
        //    BookDto _book = bookRepo.GetBook("A Book");

        //    //Act
        //    var book = bookRepo.DeleteBook(_book.ISBN);

        //    //Assert
        //    if (bookRepo.GetBook("A Book") == null)
        //        Assert.Pass();

        //    Assert.Fail();
        //}

        //[Test]
        //public void DeleteBook_WithNoData()
        //{
        //    //Arrange
        //    InMemoBookRepo bookRepo = new InMemoBookRepo();

        //    //Act
        //    var book = bookRepo.DeleteBook(String.Empty);

        //    //Assert
        //    if (book == false)
        //        Assert.Pass();

        //    Assert.Fail();
        //}

        //[Test]
        //public void DeleteBook_WithUnExistaningData()
        //{
        //    //Arrange
        //    InMemoBookRepo bookRepo = new InMemoBookRepo();
        //    bookRepo.CreateBook(new CreateOrUpdateBookDto { Title = "A Book", Author = "Avinaba Srimany", Price = 1 });
        //    BookDto _book = bookRepo.GetBook("A Book");

        //    //Act
        //    var book = bookRepo.DeleteBook(_book.ISBN + "154");

        //    //Assert
        //    if (bookRepo.GetBook("A Book") == _book)
        //        Assert.Pass();

        //    Assert.Fail();
        //}

        //[Test]
        //public void UpdateBook_WithExistaningData()
        //{
        //    //Arrange
        //    InMemoBookRepo bookRepo = new InMemoBookRepo();
        //    bookRepo.CreateBook(new CreateOrUpdateBookDto { Title = "A Book", Author = "Avinaba Srimany", Price = 1 });
        //    BookDto _book = bookRepo.GetBook("A Book");

        //    //Act
        //    var book = bookRepo.UpdateBook(_book.ISBN, new CreateOrUpdateBookDto() { Author = _book.Author, Price = _book.Price, Title = "B Book"});

        //    //Assert
        //    if (bookRepo.GetBook("A Book") == null && bookRepo.GetBook("B Book") != null)
        //        Assert.Pass();

        //    Assert.Fail();
        //}

        //[Test]
        //public void UpdateBook_WithNoData()
        //{
        //    //Arrange
        //    InMemoBookRepo bookRepo = new InMemoBookRepo();

        //    //Act
        //    var book = bookRepo.UpdateBook(String.Empty, new CreateOrUpdateBookDto());

        //    //Assert
        //    if (book == null)
        //        Assert.Pass();

        //    Assert.Fail();
        //}

        //[Test]
        //public void UpdateBook_WithUnExistaningData()
        //{
        //    //Arrange
        //    InMemoBookRepo bookRepo = new InMemoBookRepo();
        //    bookRepo.CreateBook(new CreateOrUpdateBookDto { Title = "A Book", Author = "Avinaba Srimany", Price = 1 });
        //    BookDto _book = bookRepo.GetBook("A Book");

        //    //Act
        //    var book = bookRepo.UpdateBook(_book.ISBN + "154", new CreateOrUpdateBookDto() { Author = _book.Author, Price = _book.Price, Title = "B Book" });

        //    //Assert
        //    if (bookRepo.GetBook("A Book") != null && bookRepo.GetBook("B Book") == null)
        //        Assert.Pass();

        //    Assert.Fail();
        //}

        private InMemoBookRepo inMemoBookRepo = new InMemoBookRepo();
        private readonly Mock<IBook> _bookRepo = new Mock<IBook>();
        private readonly Random rand = new Random();

        [Test]
        public void GetBook_WithUnExistaningData()
        {
            //Arrange
            _bookRepo.Setup(x => x.GetBook(It.IsAny<Guid>().ToString()))
                .Returns((BookDto)null);

            var controller = new BooksController(_bookRepo.Object);

            //Act
            var result = controller.GetBook(Guid.NewGuid().ToString());

            //Assert
            Assert.IsInstanceOf<NotFoundResult>(result.Result);
        }

        [Test]
        public void GetBook_WithExistaningData()
        {
            //Arrange
            var expectedBook = CreateBook();
            _bookRepo.Setup(x => x.GetBook(It.IsAny<Guid>().ToString()))
                .Returns(expectedBook);

            var controller = new BooksController(_bookRepo.Object);

            //Act
            var result = controller.GetBook(Guid.NewGuid().ToString());

            //Assert
            Assert.IsInstanceOf<BookDto>(result.Value);
        }

        [Test]
        public void GetBooks_WithExistaningData()
        {
            //Arrange
            var expectedBook = new[] { CreateBook(), CreateBook(), CreateBook() };
            _bookRepo.Setup(x => x.GetBooks())
                .Returns(expectedBook);

            var controller = new BooksController(_bookRepo.Object);

            //Act
            var result = controller.GetBooks();

            //Assert
            Assert.IsInstanceOf<IEnumerable<BookDto>>(result.Value);
        }

        [Test]
        public void CreateBook_WithItemToCreate()
        {
            //Arrange
            var _bookToCreate = new CreateOrUpdateBookDto()
            {
                Author = Guid.NewGuid().ToString(),
                Title = Guid.NewGuid().ToString(),
                Price = rand.Next((int)10000.00)
            };

            var controller = new BooksController(_bookRepo.Object);
            //Act
            var result = controller.CreateBook(_bookToCreate);

            //Assert
            Assert.IsInstanceOf<CreatedAtActionResult>(result as CreatedAtActionResult);
        }

        [Test]
        public void UpdateBook_WithExistingItem()
        {
            //Arrange
            var expectedBook = CreateBook();
            _bookRepo.Setup(x => x.GetBook(It.IsAny<Guid>().ToString()))
                .Returns(expectedBook);

            var bookISBN = expectedBook.ISBN;
            var bookToUpdate = new CreateOrUpdateBookDto()
            {
                Author = Guid.NewGuid().ToString(),
                Title = Guid.NewGuid().ToString(),
                Price = rand.Next((int)10000.00)
            };

            var controller = new BooksController(_bookRepo.Object);
            //Act
            var result = controller.UpdateBook(bookISBN, bookToUpdate);

            //Assert
            Assert.IsInstanceOf<OkResult>(result.Result);
        }

        [Test]
        public void DeleteBook_WithExistingItem()
        {
            //Arrange
            var expectedBook = CreateBook();
            _bookRepo.Setup(x => x.GetBook(It.IsAny<Guid>().ToString()))
                .Returns(expectedBook);

            var controller = new BooksController(_bookRepo.Object);
            //Act
            var result = controller.DeleteBook(expectedBook.ISBN);

            //Assert
            Assert.IsInstanceOf<AcceptedAtActionResult>(result as AcceptedAtActionResult);
        }

        private BookDto CreateBook()
        {
            return new BookDto()
            {
                ISBN = Guid.NewGuid().ToString(),
                Author = Guid.NewGuid().ToString(),
                Title = Guid.NewGuid().ToString(),
                Price = rand.Next((int)10000.00),
                PublicationDt = DateTime.Now
            };
        }
    }
}