﻿using System.ComponentModel.DataAnnotations;

namespace BookCatalog.Models
{
    public class Book
    {
        [Required]
        public string ISBN { get; set; }
        [Required]
        public string Title { get; set; }
        [Required]
        public string Author { get; set; }
        [Required]
        [Range (0, 10000.00)]
        public decimal Price { get; set; }
        [Required]
        public DateTime PublicationDt { get; set; }
    }
}
