﻿using BookCatalog.Dtos;
using BookCatalog.Models;

namespace BookCatalog.Repo
{
    public class InMemoBookRepo : IBook
    {
        public List<Book> _Books;

        public InMemoBookRepo()
        {
            _Books = new List<Book>()
            {
                new Book{ ISBN = Guid.NewGuid().ToString(), Author = "Authr1", Title = "Book1", Price = 87, PublicationDt = DateTime.Now },
                new Book{ ISBN = Guid.NewGuid().ToString(), Author = "Authr2", Title = "Book2", Price = 54, PublicationDt = DateTime.Now },
                new Book{ ISBN = Guid.NewGuid().ToString(), Author = "Authr3", Title = "Book3", Price = 65, PublicationDt = DateTime.Now },
            };
        }

        public void CreateBook(CreateOrUpdateBookDto book)
        {
            var _book = new Book { ISBN = Guid.NewGuid().ToString(), Author = book.Author, Title = book.Title, Price = book.Price, PublicationDt = DateTime.Now };
            _Books.Add(_book);
        }

        public bool DeleteBook(string val)
        {
            try
            {
                var index = _Books.FindIndex(x => x.ISBN == val);

                if (index == -1)
                {
                    return false;
                }

                _Books.RemoveAt(index);

                return true;
            }
            catch (Exception)
            {
                //Log need to be maintain to record the ex.Message
                return false;
            }
        }

        public BookDto GetBook(string val)
        {
            try
            {
                //for ISBN based search
                var book = _Books.Where(x => x.ISBN == val).FirstOrDefault();

                //for Author based search
                if (book == null)
                {
                    book = _Books.Where(x => x.Author == val).FirstOrDefault();
                }

                //for Title based search
                if (book == null)
                {
                    book = _Books.Where(x => x.Title == val).FirstOrDefault();
                }

                if (book == null)
                    return null;
                else
                    return new BookDto { ISBN = book.ISBN, Author = book.Author, Title = book.Title, Price = book.Price, PublicationDt = book.PublicationDt };
            }
            catch (Exception ex)
            {
                //Log need to be maintain to record the ex.Message
                return null;
            }
        }

        public IEnumerable<BookDto> GetBooks()
        {
            return _Books.Select(x => new BookDto { ISBN = x.ISBN, Author = x.Author, Price = x.Price, PublicationDt = x.PublicationDt, Title = x.Title });
        }

        public BookDto UpdateBook(string iSBN, CreateOrUpdateBookDto book)
        {
            try
            {
                var _book = _Books.Where(x => x.ISBN == iSBN).Select(x => new CreateOrUpdateBookDto { Author = book.Author, Title = book.Title, Price = book.Price }).FirstOrDefault();

                if (_book == null)
                {
                    return null;
                }

                _Books.Where(x => x.ISBN == iSBN).ToList()
                    .ForEach(i =>
                    {
                        i.Author = _book.Author;
                        i.Title = _book.Title;
                        i.Price = _book.Price;
                    });

                return GetBook(iSBN);
            }
            catch (Exception)
            {
                //Log need to be maintain to record the ex.Message
                return null;
            }
        }
    }
}
