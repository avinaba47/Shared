﻿using BookCatalog.Dtos;
using BookCatalog.Models;

namespace BookCatalog.Repo
{
    public interface IBook
    {
        public IEnumerable<BookDto> GetBooks();
        public BookDto GetBook(string val);
        public bool DeleteBook(string val);
        public void CreateBook(CreateOrUpdateBookDto book);
        public BookDto UpdateBook(string iSBN, CreateOrUpdateBookDto book);

    }
}
