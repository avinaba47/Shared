﻿using System.ComponentModel.DataAnnotations;

namespace BookCatalog.Dtos
{
    public record BookDto
    {
        [Required]
        public string ISBN { get; set; }
        [Required]
        public string Title { get; set; }
        [Required]
        public string Author { get; set; }
        [Required]
        [Range(0, 10000.00)]
        public decimal Price { get; set; }
        [Required]
        public DateTime PublicationDt { get; set; }

        public void Returns(BookDto expectedBook)
        {
            throw new NotImplementedException();
        }
        //{ get { return PublicationDt; } set { PublicationDt = (Convert.ToString(value) == "" ? new DateTime() : value); } }
    }
}
