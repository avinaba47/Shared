﻿using BookCatalog.Dtos;
using BookCatalog.Models;
using BookCatalog.Repo;
using Microsoft.AspNetCore.Mvc;

namespace BookCatalog.Controllers
{
    [ApiController]
    [Route("books")]
    public class BooksController:ControllerBase
    {
        private IBook _BooksRepo;
        public BooksController(IBook _Book)
        {
            this._BooksRepo = _Book;
        }

        [HttpGet]
        public ActionResult<IEnumerable<BookDto>> GetBooks()
        {
            var _book = _BooksRepo.GetBooks().ToList();

            if (_book.Count == 0)
                return NotFound();
            else
                return _book;
        }

        [HttpGet("{val}")]
        public ActionResult<BookDto> GetBook(string val)
        {
            var _book = _BooksRepo.GetBook(val);

            if(_book == null)
            {
                return NotFound();
            }

            return _book;
        }

        [HttpPost]
        public IActionResult CreateBook(CreateOrUpdateBookDto book)
        {
            _BooksRepo.CreateBook(book);
            return Ok();
        }

        [HttpPut("{ISBN}")]
        public ActionResult<BookDto> UpdateBook(string ISBN, CreateOrUpdateBookDto book)
        {
            var _book = _BooksRepo.UpdateBook(ISBN, book);

            if (_book == null)
            {
                return NotFound();
            }

            return _book;
        }

        [HttpDelete("{ISBN}")]
        public IActionResult DeleteBook(string ISBN)
        {
            var _book = _BooksRepo.DeleteBook(ISBN);

            if (_book == false)
            {
                return NotFound();
            }

            return Ok();
        }

    }
}
